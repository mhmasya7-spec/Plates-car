package com.example.platehunter

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Text post-processor. This is not Gemini Live audio streaming. */
object GeminiPlateHelper {
    /** Extract every confidently spoken plate from a transcript, preserving order. Call on a worker thread. */
    fun extractPlates(apiKey: String, transcript: String): List<String> {
        if (apiKey.isBlank() || transcript.isBlank()) return emptyList()
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 15000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val prompt = "أنت مدقق تفريغ لوحات سيارات سعودية. استخرج كل اللوحات المذكورة في النص بالترتيب، وليس لوحة واحدة فقط. اللوحة 3 حروف عربية ثم 4 أرقام، مثال سرط7520. " +
                "اعتبر كلمة لوحة أو ولوحة بداية لوحة جديدة، ولا تسقط أي لوحة تالية. أسماء الحروف مثل راء سين عين تتحول إلى رسع. " +
                "الأرقام قد تقال رقمًا رقمًا مثل خمسة سبعة تسعة خمسة = 5795، أو كمجموعات مثل خمسة وسبعين عشرين = 7520، وخمشة وسبعين عشرين = 7520. " +
                "إذا كان جزء الأرقام 3 أرقام فقط أضف صفرًا في البداية ليصبح 4 أرقام. لا تخمن ولا تكمل جزءًا ناقصًا. " +
                "أعد JSON فقط بالشكل {\"plates\":[\"سرط7520\",\"اعب7141\"]}. إذا لم توجد لوحة واضحة أعد {\"plates\":[]}. النص: $transcript"
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return emptyList()
            val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val answer = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")?.trim().orEmpty()
            val jsonText = answer.substringAfter('{', "").let { if (it.isNotEmpty()) "{$it" else "" }
            val arr = JSONObject(jsonText).optJSONArray("plates") ?: return emptyList()
            buildList {
                for (idx in 0 until arr.length()) {
                    val normalized = PlateParser.normalize(arr.optString(idx))
                    if (normalized.isNotBlank()) add(normalized)
                }
            }
        } catch (_: Exception) { emptyList() } finally { conn?.disconnect() }
    }

    /** Backward-compatible single-plate helper. */
    fun extractPlate(apiKey: String, transcript: String): String? = extractPlates(apiKey, transcript).firstOrNull()
}
