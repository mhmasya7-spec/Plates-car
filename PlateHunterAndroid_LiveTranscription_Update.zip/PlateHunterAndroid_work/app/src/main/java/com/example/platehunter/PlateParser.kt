package com.example.platehunter

/** Arabic Saudi plate parsing helpers. Handles both digit-by-digit speech and grouped colloquial numbers. */
object PlateParser {
    private val digits = mapOf(
        "صفر" to "0", "واحد" to "1", "واحدة" to "1", "واحده" to "1",
        "اثنين" to "2", "اتنين" to "2", "اثنان" to "2", "تنين" to "2", "ثنين" to "2",
        "ثلاثة" to "3", "ثلاثه" to "3", "ثلاث" to "3",
        "اربعة" to "4", "أربعة" to "4", "اربعه" to "4", "أربعه" to "4",
        "خمسة" to "5", "خمسه" to "5", "خمشة" to "5", "خمشه" to "5",
        "ستة" to "6", "سته" to "6", "سبعة" to "7", "سبعه" to "7",
        "ثمانية" to "8", "تمانية" to "8", "ثمانيه" to "8", "تسعة" to "9", "تسعه" to "9"
    )
    private val tens = mapOf(
        "عشرة" to 10, "عشره" to 10, "عشر" to 10,
        "عشرين" to 20, "عشرون" to 20, "ثلاثين" to 30, "أربعين" to 40, "اربعين" to 40,
        "خمسين" to 50, "ستين" to 60, "سبعين" to 70, "ثمانين" to 80, "تسعين" to 90
    )
    private val letters = mapOf(
        "ألف" to "ا", "الف" to "ا", "أ" to "ا", "ا" to "ا",
        "باء" to "ب", "تاء" to "ت", "ثاء" to "ث", "جيم" to "ج", "حاء" to "ح", "خاء" to "خ",
        "دال" to "د", "ذال" to "ذ", "راء" to "ر", "زاي" to "ز", "زين" to "ز", "سين" to "س", "شين" to "ش",
        "صاد" to "ص", "ضاد" to "ض", "طاء" to "ط", "ظاء" to "ظ", "عين" to "ع", "غين" to "غ",
        "فاء" to "ف", "قاف" to "ق", "كاف" to "ك", "لام" to "ل", "ميم" to "م", "نون" to "ن",
        "هاء" to "ه", "واو" to "و", "ياء" to "ي"
    )
    private val markers = setOf("لوحة", "لوحه", "اللوحة", "اللوحه", "رقم", "رقمها", "واللوحة", "ولوحة")

    fun normDigits(s: String) = s.replace('٠','0').replace('١','1').replace('٢','2')
        .replace('٣','3').replace('٤','4').replace('٥','5').replace('٦','6')
        .replace('٧','7').replace('٨','8').replace('٩','9')

    private fun cleanToken(token: String): String {
        var t = token.trim().lowercase()
        t = t.trim(',', '،', ';', '؛', '.', '!', '؟', '?', ':')
        if (t.startsWith("و") && (letters.containsKey(t.drop(1)) || digits.containsKey(t.drop(1)) || tens.containsKey(t.drop(1)))) t = t.drop(1)
        return t
    }

    fun normalize(s: String): String {
        val x = normDigits(s).replace(Regex("[\\s\\-،,:؛.]"), "")
        val l = x.filter { it in 'ء'..'ي' || it == 'أ' || it == 'إ' || it == 'آ' }
        val d = x.filter { it.isDigit() }
        if (l.length != 3 || d.length !in 3..4) return ""
        return l + if (d.length == 3) "0$d" else d
    }

    private fun readNumber(tokens: List<String>, start: Int): Pair<String, Int> {
        val out = StringBuilder()
        var i = start
        while (i < tokens.size && out.length < 4) {
            val token = cleanToken(tokens[i])
            if (token == "و") { i++; continue }
            val raw = normDigits(token).filter { it.isDigit() }
            if (raw.isNotEmpty()) {
                out.append(raw); i++; continue
            }
            val single = digits[token]
            val ten = tens[token]
            if (single != null) {
                // Colloquial forms such as "خمسة وسبعين" mean 75, not 5 followed by 70.
                val next = if (i + 1 < tokens.size) cleanToken(tokens[i + 1]) else ""
                val nextTen = tens[next]
                if (nextTen != null && nextTen >= 20 && nextTen % 10 == 0) {
                    out.append(nextTen + single.toInt()); i += 2
                } else {
                    out.append(single); i++
                }
                continue
            }
            if (ten != null) { out.append(ten); i++; continue }
            break
        }
        return out.toString().take(4) to i
    }

    fun fromSpeech(s: String): List<String> {
        val tokens = s.replace(Regex("[،,؛;.!؟?\\n\\r]+"), " ")
            .trim().split(Regex("\\s+")).filter { it.isNotBlank() }.map(::cleanToken)
        val out = mutableListOf<String>()
        var i = 0
        while (i < tokens.size) {
            if (tokens[i] in markers) { i++; continue }
            val lettersOut = StringBuilder()
            var j = i
            // Speech engines may return either letter names ("راء سين عين") or the joined letters ("رسع").
            val directLetters = tokens[j].filter { it in 'ء'..'ي' || it == 'أ' || it == 'إ' || it == 'آ' }
            if (directLetters.length == 3 && directLetters.all { !it.isDigit() } && tokens[j] !in markers && tokens[j] !in letters) {
                lettersOut.append(directLetters.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا'))
                j++
            } else {
                while (j < tokens.size && lettersOut.length < 3 && letters.containsKey(tokens[j])) {
                    lettersOut.append(letters[tokens[j]]); j++
                }
            }
            if (lettersOut.length == 3) {
                val (number, end) = readNumber(tokens, j)
                if (number.length in 3..4) {
                    val plate = lettersOut.toString() + if (number.length == 3) "0$number" else number
                    out.add(plate)
                    i = end.coerceAtLeast(j)
                    continue
                }
            }
            i++
        }
        // Do not use distinct(): repeated sightings are real events and should be saved separately.
        return out
    }
}
