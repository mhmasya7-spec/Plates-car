package com.example.platehunter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var spoken: TextView
    private lateinit var recordsBox: LinearLayout
    private var sr: SpeechRecognizer? = null
    private var listening = false
    private val records = mutableListOf<JSONObject>()
    private val wanted = mutableSetOf<String>()
    // Prevent the same plate from being saved repeatedly as Deepgram revises an interim result.
    // A plate spoken again after this short window is treated as a new sighting.
    private val recentVoicePlates = mutableMapOf<String, Long>()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private lateinit var listenButton: Button
    private lateinit var modeSpinner: Spinner
    private var cloudSpeech: CloudSpeech? = null
    private val prefs by lazy { getSharedPreferences("platehunter_settings", MODE_PRIVATE) }
    private fun mode(): Int = if (::modeSpinner.isInitialized) modeSpinner.selectedItemPosition else prefs.getInt("mode", 0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui()
        load()
        val missing = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
            .filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 4)
        render()
    }

    private fun ui() {
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,20,20,20) }
        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text=s; textSize=size; setPadding(4,10,4,10)
        }
        content.addView(label("مطابقة لوحات السيارات", 25f))
        status = label("جاهز — ابدأ الاستماع")
        spoken = label("الكلام المسموع سيظهر هنا")
        content.addView(status); content.addView(spoken)
        content.addView(label("طريقة التعرف على الكلام", 18f))
        modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("محلي من أندرويد (قد يحتاج إنترنت حسب الجهاز)", "Deepgram مباشر", "Deepgram + Gemini (مراجعة كل النص واللوحات)"))
            setSelection(prefs.getInt("mode", 0).coerceIn(0, 2))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { prefs.edit().putInt("mode", position).apply() }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        }
        content.addView(modeSpinner)
        content.addView(Button(this).apply { text = "⚙️ إعداد مفاتيح Deepgram وGemini"; setOnClickListener { showApiSettings() } })
        listenButton = Button(this).apply {
            text = "🎙️ بدء الاستماع المباشر"
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        content.addView(listenButton)
        val input = EditText(this).apply { hint = "لوحة يدويًا مثل سرط7520" }
        content.addView(input)
        content.addView(Button(this).apply {
            text = "إضافة يدويًا"
            setOnClickListener {
                val p = PlateParser.normalize(input.text.toString())
                if (p.isBlank()) toast("أدخل 3 حروف و3 أو 4 أرقام") else { savePlate(p,"manual"); input.setText("") }
            }
        })
        content.addView(Button(this).apply {
            text = "استيراد المطلوبين من Excel أو CSV"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv","text/plain","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                }
                startActivityForResult(i, 10)
            }
        })
        content.addView(Button(this).apply { text="تصدير السجلات لبرنامج Excel (CSV)"; setOnClickListener { export() } })
        content.addView(Button(this).apply {
            text="فتح آخر موقع على الخريطة"
            setOnClickListener {
                val r = records.lastOrNull()
                val lat = r?.optDouble("lat", Double.NaN) ?: Double.NaN
                val lon = r?.optDouble("lon", Double.NaN) ?: Double.NaN
                if (lat.isFinite() && lon.isFinite()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
                else toast("لا يوجد موقع محفوظ")
            }
        })
        content.addView(label("آخر السجلات", 20f))
        recordsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(recordsBox)
        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun startListening() {
        if (mode() == 1 || mode() == 2) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4); return
            }
            val dg = prefs.getString("deepgram_key", "").orEmpty()
            if (dg.isBlank()) { showApiSettings(); toast("أدخل مفتاح Deepgram أولًا"); return }
            listening = true; listenButton.text = "⏹ إيقاف الاستماع"; status.text = "جاري الاتصال بـ Deepgram…"
            cloudSpeech = CloudSpeech({ transcript, isFinal -> runOnUiThread {
                // Show every partial update immediately. Deepgram interim transcripts are revised
                // while the user is still speaking, so never wait for speech_final to update the UI.
                spoken.text = transcript
                val plates = PlateParser.fromSpeech(transcript)
                val captureMethod = if (mode() == 2) "deepgram+gemini" else "deepgram"
                // Parse both interim and final segments. This lets a complete plate be captured
                // before the speaker starts the next one, instead of depending on a later full utterance.
                plates.forEach { saveVoicePlateIfNew(it, captureMethod) }
                if (isFinal && mode() == 2) {
                    val key = prefs.getString("gemini_key", "").orEmpty()
                    if (key.isBlank()) {
                        if (plates.isEmpty()) status.text = "لم أستخرج لوحة واضحة؛ أضف مفتاح Gemini من الإعدادات"
                    } else {
                        status.text = "تم تحديث النص المباشر؛ Gemini يراجع المقطع النهائي…"
                        Thread {
                            val cloudPlates = GeminiPlateHelper.extractPlates(key, transcript)
                            runOnUiThread {
                                if (listening) {
                                    cloudPlates.forEach { saveVoicePlateIfNew(it, "deepgram+gemini") }
                                    if (cloudPlates.isEmpty() && plates.isEmpty()) status.text = "لم يتم استخراج لوحة مؤكدة"
                                    else status.text = "تمت مراجعة المقطع؛ استمر في قول اللوحات"
                                }
                            }
                        }.start()
                    }
                } else if (isFinal && plates.isEmpty()) {
                    status.text = "لم أستخرج لوحة واضحة من هذا المقطع؛ الاستماع مستمر"
                }
            } }, { message -> runOnUiThread { status.text = message } }).also { it.start(dg) }
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("خدمة التعرف على الكلام غير متاحة"); return }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4); return
        }
        listening = true; listenButton.text = "⏹ إيقاف الاستماع"; status.text = "🎙️ جاري الاستماع"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { sr?.destroy() } catch (_: Exception) {}
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "الميكروفون جاهز" }
            override fun onBeginningOfSpeech() { status.text = "بسمعك..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restart(intent) }
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(::process)
                restart(intent)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { spoken.text = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { sr?.startListening(intent) } catch (_: Exception) { status.text = "تعذر بدء الميكروفون" }
    }

    private fun restart(intent: Intent) {
        if (!listening) return
        window.decorView.postDelayed({
            if (listening) try { sr?.cancel(); sr?.startListening(intent) }
            catch (_: Exception) { status.text = "توقف الاستماع؛ اضغط بدء الاستماع مرة أخرى" }
        }, 400)
    }

    private fun process(s: String) {
        spoken.text = s
        val ps = PlateParser.fromSpeech(s)
        if (ps.isEmpty()) status.text = "لم أستخرج لوحة واضحة"
        else ps.forEach { savePlate(it, "voice") }
    }

    private fun stopListening() {
        listening = false
        try { cloudSpeech?.stop() } catch (_: Exception) {}; cloudSpeech = null
        try { sr?.cancel(); sr?.destroy() } catch (_: Exception) {}
        sr = null; listenButton.text = "🎙️ بدء الاستماع المباشر"; status.text = "تم إيقاف الاستماع"
    }

    private fun location(): Location? {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            listOfNotNull(
                try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Exception) { null },
                try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
            ).maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    private fun saveVoicePlateIfNew(rawPlate: String, method: String) {
        val p = PlateParser.normalize(rawPlate)
        if (p.isBlank()) return
        val now = System.currentTimeMillis()
        val previous = recentVoicePlates[p]
        // Interim and final responses for the same spoken plate usually arrive within seconds.
        // Suppress that technical duplicate, but allow a later repeat to count as a new sighting.
        if (previous != null && now - previous < 4500L) return
        recentVoicePlates[p] = now
        // Keep this session map bounded during long work shifts.
        recentVoicePlates.entries.removeAll { now - it.value > 120_000L }
        savePlate(p, method)
    }

    private fun savePlate(p: String, method: String) {
        val nowMs = System.currentTimeMillis()
        val last = records.lastOrNull()
        if (last != null && last.optString("plate") == p && nowMs - last.optLong("epoch") < 8000) return
        val loc = location()
        val r = JSONObject().apply {
            put("plate",p); put("timestamp",fmt.format(Date())); put("epoch",nowMs); put("method",method)
            put("lat",loc?.latitude ?: JSONObject.NULL); put("lon",loc?.longitude ?: JSONObject.NULL)
            put("map",if (loc != null) "https://maps.google.com/?q=${loc.latitude},${loc.longitude}" else "")
            put("matched",wanted.contains(p))
        }
        records.add(r); persist(); render()
        status.text = if (wanted.contains(p)) "⚠️ $p موجودة في قائمة المطلوبين" else "تم تسجيل $p"
    }

    private fun load() {
        try {
            val f=File(filesDir,"records.json")
            if (f.exists()) { val a=JSONArray(f.readText()); for(i in 0 until a.length()) records.add(a.getJSONObject(i)) }
        } catch (_: Exception) {}
    }
    private fun persist() {
        try { val a=JSONArray(); records.forEach { a.put(it) }; File(filesDir,"records.json").writeText(a.toString()) }
        catch (_: Exception) { toast("تعذر حفظ السجلات") }
    }
    private fun render() {
        if (!::recordsBox.isInitialized) return
        recordsBox.removeAllViews()
        records.takeLast(40).reversed().forEach { r ->
            val t = "${r.optString("plate")} | ${r.optString("timestamp")}\n" +
                (if (r.optBoolean("matched")) "موجودة في المطلوبين" else "غير موجودة في القائمة") +
                (if (r.optString("map").isNotBlank()) "\n${r.optString("map")}" else "\nالموقع غير متاح")
            recordsBox.addView(TextView(this).apply { text=t; textSize=14f; setPadding(10,10,10,10) })
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            try {
                val uri = data?.data ?: return
                val imported = SpreadsheetReader.readPlateColumn(contentResolver, uri)
                    .mapNotNull { PlateParser.normalize(it).takeIf(String::isNotBlank) }
                wanted.clear(); wanted.addAll(imported)
                records.forEach { it.put("matched", wanted.contains(it.optString("plate"))) }
                persist(); render(); toast("تم استيراد ${wanted.size} لوحة ومطابقة السجلات")
            } catch (e: Exception) {
                toast(e.message ?: "تعذر قراءة الملف؛ جرّب XLSX أو CSV")
            }
        }
    }

    private fun export() {
        try {
            val csv = buildString {
                append("\uFEFFplate,matched,timestamp,latitude,longitude,map,capture_method\n")
                records.forEach { r ->
                    val cols = listOf(r.optString("plate"),r.optBoolean("matched").toString(),r.optString("timestamp"),
                        r.opt("lat").toString(),r.opt("lon").toString(),r.optString("map"),r.optString("method"))
                    append(cols.joinToString(",") { "\"${it.replace("\"","\"\"")}\"" }).append('\n')
                }
            }
            val f=File(cacheDir,"plate_records.csv"); f.writeText(csv,Charsets.UTF_8)
            val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",f)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type="text/csv"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            },"تصدير السجلات"))
        } catch (_: Exception) { toast("تعذر التصدير") }
    }

    private fun showApiSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val deepgram = EditText(this).apply { hint = "Deepgram API Key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("deepgram_key", "")) }
        val gemini = EditText(this).apply { hint = "Gemini API Key (اختياري)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("gemini_key", "")) }
        box.addView(TextView(this).apply { text = "للاستخدام الشخصي فقط: حفظ المفتاح داخل الهاتف ليس حماية كاملة. لا تنشر APK بمفاتيحك."; textSize = 13f })
        box.addView(deepgram); box.addView(gemini)
        android.app.AlertDialog.Builder(this).setTitle("إعداد مفاتيح API").setView(box)
            .setPositiveButton("حفظ") { _, _ -> prefs.edit().putString("deepgram_key", deepgram.text.toString().trim()).putString("gemini_key", gemini.text.toString().trim()).apply(); toast("تم حفظ الإعدادات على هذا الهاتف") }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    override fun onDestroy() { listening=false; try { cloudSpeech?.stop() } catch (_: Exception) {}; try { sr?.destroy() } catch (_: Exception) {}; super.onDestroy() }
}
